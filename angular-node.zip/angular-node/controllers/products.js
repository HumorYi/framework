/*
 * Base Dependencies
 */


/*
 * Server Dependencies
 */
var debug = require('debug')('u-practice:controller:products');
var GameDB = require('../../models/game');
var Product = GameDB.models.product;

/*
 * UModules Dependencies
 */
var Game = require('../../game/');
var GE = Game.ERROR;

module.exports = {
    name: "products",

    list: function(req, res, next) {
        var body      = {};
        var page      = parseInt(req.query.page) || 1;
        var pageCount = parseInt(req.query.page_count) || 50;

        Product.findAndCountAll({
            where: { system: 0, agent: 1 },
            offset: (page - 1) * pageCount,
            limit: pageCount
        }).then(function(results) {
            var count = results.count;
            var records = results.rows;

            body.count      = count;
            body.total      = Math.ceil(count/pageCount);
            body.page       = page;
            body.pageCount  = pageCount;
            body.data       = [];

            records.forEach(function(record) {
                body.data.push(record.toJSON());
            });

            res.success(body);
        }).catch(function(e) {
            next(e);
        });
    },

    get: function(req, res, next) {
        var id = req.params.id;

        Product.findOne({
            where: { id: id }
        }).then(function(record) {
            if (record == null) {
                res.error(GE.NOT_EXISTS);
                return;
            }

            var data = record.toJSON();

            delete data.password;

            res.success(data);
        }).catch(function(e) {
            next(e);
        });
    },

    create: function(req, res, next) {
        var productAdd = req.body.productAdd;

        Product.findOne({
            where: { name: productAdd.name }
        }).then(function (record) {
           if(record != null){
               throw new ServerError(GE.ALREADY_EXISTS);
           }

           return Product.create({
               name: productAdd.name,
               desc: productAdd.desc,
               price: productAdd.price,
               tokens: productAdd.tokens,
               upShelf: productAdd.upShelf
           });
        }).then(function(record) {
            res.success(record.toJSON());
        }).catch(function(e) {
            next(e);
        });
    },

    update: function(req, res, next) {
        var id = req.params.id;
        var productCheck = req.body.productCheck;

        Product.update({
            name: productCheck.name,
            desc: productCheck.desc,
            price: productCheck.price * 100,
            tokens: productCheck.tokens,
            upShelf: productCheck.upShelf
        }, {
            where: { id: id }
        }).then(function(results) {
            res.success();
        }).catch(function(e) {
            next(e);
        });
    },

    delete: function(req, res, next) {
        var id = req.params.id;

        Product.destroy({
            where: { id: id }
        }).then(function(results) {
            res.success();
        }).catch(function(e) {
            next(e);
        });
    }
};
