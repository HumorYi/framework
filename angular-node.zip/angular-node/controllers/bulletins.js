/*
 * Base Dependencies
 */


/*
 * Server Dependencies
 */
var debug = require('debug')('u-practice:controller:bulletins');
var GameDB = require('../../models/game');
var Bulletin = GameDB.models.bulletin;

/*
 * UModules Dependencies
 */
var Game = require('../../game/');
var GE = Game.ERROR;

module.exports = {
    name: "bulletins",

    list: function(req, res, next) {
        var body      = {};
        var page      = parseInt(req.query.page) || 1;
        var pageCount = parseInt(req.query.page_count) || 50;

        Bulletin.findAndCountAll({
            where: { system: 0, agent: 1 },
            offset: (page - 1) * pageCount,
            limit: pageCount
        }).then(function(results) {
            var count = results.count;
            var records = results.rows;

            body.count      = count;
            body.total      = Math.ceil(count/pageCount);
            body.page       = page;
            body.pageCount  = pageCount;
            body.data       = [];

            records.forEach(function(record) {
                body.data.push(record.toJSON());
            });

            res.success(body);
        }).catch(function(e) {
            next(e);
        });
    },

    get: function(req, res, next) {
        var id = req.params.id;

        Bulletin.findOne({
            where: { id: id }
        }).then(function(record) {
            if (record == null) {
                res.error(GE.NOT_EXISTS);
                return;
            }

            var data = record.toJSON();

            delete data.password;

            res.success(data);
        }).catch(function(e) {
            next(e);
        });
    },

    create: function(req, res, next) {
        var bulletinAdd = req.body.bulletinAdd;

        Bulletin.findOne({
            where: { title: bulletinAdd.title }
        }).then(function (record) {
            if (record != null) {
                throw new ServerError(GE.ALREADY_EXISTS);
            }

            return Bulletin.create({
                title: bulletinAdd.title,
                summary: bulletinAdd.summary,
                content: bulletinAdd.content,
                startTime: bulletinAdd.startTime,
                endTime: bulletinAdd.endTime,
                priority: bulletinAdd.priority
            });
        }).then(function(record) {
            res.success(record.toJSON());
        }).catch(function(e) {
            next(e);
        });
    },

    update: function(req, res, next) {
        var id = req.params.id;
        var bulletinCheck = req.body.bulletinCheck;

        Bulletin.update({
            title: bulletinCheck.title,
            summary: bulletinCheck.summary,
            content: bulletinCheck.content,
            startTime: bulletinCheck.startTime,
            endTime: bulletinCheck.endTime,
            priority: bulletinCheck.priority
        }, {
            where: { id: id }
        }).then(function(results) {
            res.success();
        }).catch(function(e) {
            next(e);
        });
    },

    delete: function(req, res, next) {
        var id = req.params.id;

        Bulletin.destroy({
            where: { id: id }
        }).then(function(results) {
            res.success();
        }).catch(function(e) {
            next(e);
        });
    }
};
