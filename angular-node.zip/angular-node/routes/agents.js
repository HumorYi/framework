/*
 * Base Dependencies
 */
var express = require('express');
var router = express.Router();

/*
 * Server Dependencies
 */
var debug = require('debug')('deju-poker:route:agents');
var app = require('../app');
var GameDB = require('../../models/game');
var agents = require('../controllers').agents;

/*
 * UModules Dependencies
 */
var Game = require('../../game');
var GE = Game.ERROR;

module.exports = {
    path: "/agents",
    route: router
};

router.get('/', agents.list);
router.post('/', agents.create);

router.get('/:id', agents.get);
router.post('/:id', agents.query);
router.put('/:id', agents.update);
router.put('/:id/updateOrDelete', agents.updateOrDelete);
router.put('/:id/accountStatus', agents.updateAccountStatus);
router.delete('/:id', agents.delete);