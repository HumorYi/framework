(function() {
    var app = angular.module('app');

    app.controller('MainController', [
        '$scope',
        'account',
        function($scope, account) {
            $scope.account = {
                name: account.account,
                scope: account.scope,
                avatar: account.avatar,
                token: account.tokens,
                country: account.country,
                province: account.province,
                city: account.city,
                id: account.id,
                parentID: account.parentID
            };

            switch ($scope.account.scope){
                case 4:
                    $scope.account.scope = '超级管理员';
                    break;
                case 3:
                    $scope.account.scope = '高级管理员';
                    break;
                case 2:
                    $scope.account.scope = '普通管理员';
                    break;
                case 1:
                    $scope.account.scope = '代理商';
                    break;
                default:
                    $scope.account.scope = '普通会员';
            }
        }
    ]);

    app.controller('LoginController', [
        '$scope',
        '$location',
        'netManager',
        function($scope, $location, netManager) {
            $scope.username = "";
            $scope.password = "";
            $scope.loginFailure = false;

            $scope.onFocus = function() {
                $scope.loginFailure = false;
            };

            $scope.submit = function() {
                if ($scope.username.length < 1) {
                    return;
                }

                if ($scope.password.length < 1) {
                    return;
                }

                netManager.login({
                    username: $scope.username,
                    password: $scope.password
                }).then(function(result) {
                    if (result == true) {
                        $location.path('/main/summary');
                    } else {
                        $scope.loginFailure = true;
                    }
                })
            };
        }
    ]);

    app.controller('PurchaseController', [
        '$scope',
        function($scope) {
        }
    ]);

    app.controller('ApplyController', [
        '$scope',
        function($scope) {
        }
    ]);

    app.controller('SummaryController', [
        '$scope',
        function($scope) {
        }
    ]);

    app.controller('AccountController', [
        '$scope',
        function($scope) {

        }
    ]);

    app.controller('OrderController', [
        '$scope',
        function($scope) {
        }
    ]);

    app.controller('AgentController', [
        '$scope',
        'netManager',
        '$uibModal',
        function($scope, netManager,$uibModal) {

            $scope.maxSize     = 5;
            $scope.currentPage = 1;
            $scope.pageCount   = 5;

            $scope.pageChanged = function(num_isBind) {
                $scope.totalItems = 0;
                $scope.agents     = [];
                netManager.get('/agents',
                    {
                        page            : $scope.currentPage,
                        page_count      : $scope.pageCount,
                        isBind          : num_isBind,
                        userid          : $scope.account.id
                    }
                ).then(function(record) {
                    var results       = record.data;

                    $scope.totalItems = results.count;
                    $scope.agents     = results.data;
                });
            };

            $scope.pageChanged(1);

            $scope.changeClassName = function (id) {
                var selector       = ".wrapper > .row > .col-lg-12 > .ibox > .ibox-content > table > tbody > tr > td > a > i";
                var plusClassName  = 'glyphicon glyphicon-plus icon-plus';
                var minusClassName = 'glyphicon glyphicon-minus icon-minus';
                var dom            = angular.element(document.querySelectorAll(selector));

                angular.forEach(dom, function(value, key) {
                    if(value.getAttribute('data-id') == id){
                        if(value.className == plusClassName){
                            value.className = minusClassName;
                        }else{
                            value.className = plusClassName;
                        }
                    }
                });
            };

            $scope.createAgent = function (id, name, num_isBind) {
                $uibModal.open({
                    templateUrl: "createAgent_modal",
                    animation  : true,
                    backdrop   : "static",
                    resolve    : {
                        pageChanged : function(){
                            return $scope.pageChanged;
                        },
                        agents      : function () {
                            return angular.copy($scope.agents);
                        }
                    },
                    controller : function($scope, $uibModalInstance, pageChanged, agents){
                        $scope.prevName = name;

                        $scope.agent = {
                            account: '',
                            password: '',
                            confirmPassword: ''
                        };

                        $scope.close = function(){
                            $uibModalInstance.close();
                        }

                        $scope.create = function () {
                            if($scope.agent.password != $scope.agent.confirmPassword){
                                alert('输入的两个密码不一致！');
                                return;
                            }

                            $scope.agent.parentID = id;

                            netManager.post(
                                '/agents',
                                { agent: $scope.agent }
                            ).then(function (result) {
                                pageChanged(num_isBind);
                                $scope.close();
                            }).catch(function (e) {
                                if(e.statusText == 'Internal Server Error'){
                                    alert('该代理名已存在，请换一个代理名！');
                                }
                            });
                        };
                    }
                });
            };

            $scope.alterPassword = function (id, nowAgent, num_isBind) {

                $uibModal.open({
                    templateUrl: "alterPassword_modal",
                    animation  : true,
                    backdrop   : "static",
                    resolve    : {
                        pageChanged: function(){
                            return $scope.pageChanged;
                        }
                    },
                    controller : function($scope, $uibModalInstance, pageChanged){
                        $scope.nowAgent = nowAgent;
                        $scope.agent = {
                            oldPassword: '',
                            newPassword: '',
                            confirmNewPassword: ''
                        };

                        $scope.close = function(){
                            $uibModalInstance.close();
                        }

                        $scope.confirmAlter = function () {

                            if($scope.agent.newPassword != $scope.agent.confirmNewPassword){
                                alert('输入的两个密码不一致！');
                            }else{
                                $scope.tableName = '';

                                if(num_isBind == 1){
                                    $scope.tableName = 'user';
                                }else{
                                    $scope.tableName = 'agent';
                                }

                                netManager.post(
                                    '/agents/' + id,
                                    {
                                        tableName: $scope.tableName
                                    }
                                ).then(function(response) {
                                    if($scope.agent.oldPassword != response.data.password){
                                        alert('原密码错误 !');
                                        return;
                                    }

                                    netManager.put(
                                        '/agents/' + id ,
                                        {
                                            tableName: $scope.tableName,
                                            newPassword: $scope.agent.newPassword
                                        }
                                    ).then(function() {
                                        pageChanged(num_isBind);
                                        $scope.close();
                                    });
                                });
                            }
                        };
                    }
                });
            };

            $scope.check = function (id, num_isBind) {
                $scope.tableName = '';

                if(num_isBind == 1){
                    $scope.bool_check   = true;
                    $scope.tableName    = 'user';
                }else{
                    $scope.bool_check   = false;
                    $scope.tableName    = 'agent';
                }

                netManager.post(
                    '/agents/' + id,
                    {
                        tableName: $scope.tableName
                    }
                ).then(function(response) {
                    $scope.currentagent = response.data;
                }).then(function(){
                    $uibModal.open({
                        templateUrl: "check_modal",
                        backdrop   : "static",
                        animation  : true,
                        resolve    : {
                            agent: function() {
                                return angular.copy($scope.currentagent);
                            }
                        },
                        controller : function($scope,$uibModalInstance,agent){
                            $scope.agent = agent;
                            if($scope.agent.gender == 0){
                                $scope.agent.gender = '男';
                            }else{
                                $scope.agent.gender = '女';
                            }

                            $scope.close=function(){
                                $uibModalInstance.close();
                            }
                        }
                    });
                });
            };

            $scope.delete = function (id, num_isBind) {
                $uibModal.open({
                    templateUrl: "delete_modal",
                    animation  : true,
                    backdrop   :"static",
                    resolve    : {
                        pageChanged : function(){
                            return $scope.pageChanged;
                        }
                    },
                    controller : function($scope, $uibModalInstance, pageChanged){
                        $scope.confirm = function () {
                            if(num_isBind == 1){
                                $scope.tableName    = 'user';
                            }else{
                                $scope.tableName    = 'agent';
                            }

                            netManager.put(
                                '/agents/' + id + '/updateOrDelete',
                                { tableName: $scope.tableName }
                            ).then(function() {
                                $uibModalInstance.close();
                                pageChanged(num_isBind);
                            });
                        };
                        $scope.cancel = function(){
                            $uibModalInstance.close();
                        }
                    }
                });
            };

            $scope.freeze = function (id, num_isBind, accountStatus) {
                $uibModal.open({
                    templateUrl: "freeze_modal",
                    animation  : true,
                    backdrop   :"static",
                    resolve    : {
                        pageChanged : function(){
                            return $scope.pageChanged;
                        }
                    },
                    controller : function($scope, $uibModalInstance, pageChanged){
                        $scope.confirm = function () {
                            netManager.put(
                                '/agents/' + id + '/accountStatus',
                                {
                                    accountStatus: accountStatus
                                }
                            ).then(function() {
                                $uibModalInstance.close();
                                pageChanged(num_isBind);
                            });
                        };
                        $scope.cancel = function(){
                            $uibModalInstance.close();
                        }
                    }
                });
            };
        }
    ]);

    app.controller('UserListController', [
        '$scope',
        'netManager',
        '$uibModal',
        function($scope, netManager,$uibModal) {

            /*会员列表 S*/
            $scope.users       = [];

            $scope.maxSize     = 5;
            $scope.totalItems  = 0;
            $scope.currentPage = 1;
            $scope.pageCount   = 5;

            $scope.pageChanged = function() {
                netManager.get('/users', { page: $scope.currentPage, page_count: $scope.pageCount })
                    .then(function(response) {
                        var results         = response.data;

                        $scope.totalItems   = results.count;
                        $scope.users        = results.data;
                    });
            };

            $scope.pageChanged();

            $scope.check = function (id) {
                netManager.get('/users/' + id)
                    .then(function(response) {
                        $scope.currentUser = response.data;
                    }).then(function(){
                    $uibModal.open({
                        templateUrl: "check_modal",
                        backdrop   : "static",
                        animation  : true,
                        resolve    : {
                            user: function() {
                                return angular.copy($scope.currentUser);
                            }
                        },
                        controller : function($scope,$uibModalInstance,user){
                            $scope.user = user;
                            if($scope.user.gender == 0){
                                $scope.user.gender = '男';
                            }else{
                                $scope.user.gender = '女';
                            }

                            $scope.close=function(){
                                $uibModalInstance.close();
                            }
                        }
                    })
                });
            };

            $scope.delete = function (id) {
                $uibModal.open({
                    templateUrl: "delete_modal",
                    animation  : true,
                    backdrop   :"static",
                    controller : function($scope,$uibModalInstance){
                        $scope.confirm = function () {
                            netManager.delete('/users/' + id
                            ).then(function() {
                                $uibModalInstance.close();
                                $scope.pageChanged();
                            });
                        };
                        $scope.cancel = function(){
                            $uibModalInstance.close();
                        }
                    }
                });
            };
            /*会员列表 E*/
        }
    ]);

    app.controller('rechargeController',[
        '$scope',
        'netManager',
        function ($scope, netManager) {
            $scope.data = {
                id    : '',
                tokens: ''
            };

            $scope.recharge = function () {

                if($scope.data.id == null){
                    return;
                }

                if($scope.data.tokens == null){
                    return;
                }

                netManager.put('/users/' + $scope.data.id + '/tokens' ,
                    {tokens: $scope.data.tokens}
                ).then(function(result) {});
            }
        }
    ]);

    app.controller('BulletinController', [
        '$scope',
        '$uibModal',
        'netManager',
        function($scope, $uibModal, netManager) {

            $scope.bulletins   = [];

            $scope.maxSize     = 5;
            $scope.totalItems  = 0;
            $scope.currentPage = 1;
            $scope.pageCount   = 5;

            $scope.pageChanged = function() {
                netManager.get('/bulletins', { page: $scope.currentPage, page_count: $scope.pageCount })
                    .then(function(response) {
                        var results = response.data;

                        $scope.totalItems = results.count;
                        $scope.bulletins  = results.data;
                    });
            };

            $scope.pageChanged();

            /*
             * 添加公告和修改公告的规则：
             问题：不确定是否会有web技术的用户人员会修改代码，从而破坏程序，
             解决：手动在js中设置验证规则
             表单内的每个数据都不允许为空(required)
             解决：要在提交前做一次表单内数据不允许为空的认证

             "开始时间"和"结束时间" 不允许写入(readonly='readonly')，只能通过日期时间控件来选择
             解决：要在提交前做一次数据验证(/^\d{4}-\d{2}-\d{2}\s?\d{2}:\d{2}:\d{2}$/.test(datetime))

             "优先权" 允许用户只能写入(type='number')，用户能够输入的内容范围为：( 数字 和 +-. )
             我们要的是正整数，为了避免用户可能输入的内容是负数
             解决：要验证用户输入的是否为正整数(/^\d+$/.test(number))
             否：提示用户只能插入数据正数
             是：此验证通过
             * */

            $scope.testFormAllContent = function (obj) {

                if( $scope.testTimeFormat(obj) ){
                    return $scope.testTimeFormat(obj);
                }

                if( $scope.testFormContentIsNull(obj) ){
                    return $scope.testFormContentIsNull(obj);
                }

                if( $scope.testIsPositiveInteger(obj) ){
                    return $scope.testIsPositiveInteger(obj);
                }

                return;
            }

            $scope.testFormContentIsNull = function (obj) {
                var nullVal = '';
                var keyToChinese = [];
                for(var key in obj){
                    if(parseInt(obj[key]) == 0){
                        continue;
                    }
                    console.log(obj[key]);

                    if(obj[key] == '' || obj[key] == undefined){
                        switch (key){
                            case 'title':
                                keyToChinese[key] = '**标题**';
                                break;
                            case 'summary':
                                keyToChinese[key] = '**概要**';
                                break;
                            case 'content':
                                keyToChinese[key] = '**内容**';
                                break;
                            case 'startTime':
                                keyToChinese[key] = '**开始时间**';
                                break;
                            case 'title':
                                keyToChinese[key] = '**结束时间**';
                                break;
                            default:
                                keyToChinese[key] = '**优先级**';
                        }
                        nullVal += keyToChinese[key] + ' 不能为空\n\n';
                    }
                }

                if(nullVal != ''){
                    return nullVal;
                }

                return;
            }

            $scope.testTimeFormat = function (obj) {

                var formatError = '';

                if(/^\d{4}-\d{2}-\d{2}\s?\d{2}:\d{2}:\d{2}$/.test( obj.startTime ) == false){
                    formatError += '**开始时间**格式错误\n';
                }

                if(/^\d{4}-\d{2}-\d{2}\s?\d{2}:\d{2}:\d{2}$/.test( obj.endTime ) == false){
                    formatError += '**结束时间**格式错误\n';
                }
                return formatError;
            }

            $scope.testIsPositiveInteger = function (obj) {
                if(/^\d+$/.test(obj.priority) == false){
                    return '**优先级**只能输入正整数';
                }
            }

            $scope.formatTime = function (key) {
                if(/^\d{4}-\d{2}-\d{2}\s?\d{2}:\d{2}:\d{2}$/.test(key) == false){
                    return key = key.format('YYYY-MM-DD HH:mm:ss');
                }
            }

            $scope.add = function () {
                $uibModal.open({
                    templateUrl: "add_modal",
                    backdrop   : "static",
                    animation  : true,
                    resolve    : {
                        testFormAllContent: function () {
                            return $scope.testFormAllContent;
                        },
                        formatTime        : function () {
                            return $scope.formatTime;
                        },
                        pageChanged       : function () {
                            return $scope.pageChanged
                        }
                    },
                    controller : function($scope, $uibModalInstance, testFormAllContent, formatTime, pageChanged){

                        $scope.bulletinAdd = {
                            title    : '',
                            summary  : '',
                            content  : '',
                            startTime: moment(),
                            endTime  : moment().add(2, 'hours'),
                            priority : 0
                        };

                        $scope.close=function(){
                            $uibModalInstance.close();
                        }

                        $scope.addBulletin = function () {

                            $scope.bulletinAdd.startTime = formatTime($scope.bulletinAdd.startTime);
                            $scope.bulletinAdd.endTime   = formatTime($scope.bulletinAdd.endTime);

                            if( testFormAllContent($scope.bulletinAdd) ){
                                alert( testFormAllContent($scope.bulletinAdd) );
                                return;
                            }

                            netManager.post(
                                '/bulletins',
                                { bulletinAdd: $scope.bulletinAdd }
                            ).then(function (result) {
                                pageChanged();
                                $scope.close();
                            });
                        }
                    }
                });
            }

            $scope.check = function (id) {
                netManager.get('/bulletins/' + id)
                    .then(function(response) {
                        $scope.currentBulletin = response.data;
                    }).then(function() {
                    $uibModal.open({
                        templateUrl: "check_modal",
                        backdrop   : "static",
                        animation  : true,
                        resolve    : {
                            currentBulletin   : function () {
                                return angular.copy($scope.currentBulletin);
                            },
                            testFormAllContent: function () {
                                return $scope.testFormAllContent;
                            },
                            formatTime        : function () {
                                return $scope.formatTime;
                            },
                            pageChanged       : function () {
                                return $scope.pageChanged;
                            }
                        },
                        controller : function ($scope, $uibModalInstance, currentBulletin, testFormAllContent, formatTime, pageChanged) {
                            $scope.close = function () {
                                $uibModalInstance.close();
                            }

                            $scope.bulletinCheck           = currentBulletin;
                            $scope.bulletinCheck.startTime = moment($scope.bulletinCheck.startTime);
                            $scope.bulletinCheck.endTime   = moment($scope.bulletinCheck.endTime);
                            $scope.bulletinCheck.priority  = parseInt($scope.bulletinCheck.priority);

                            $scope.alterBulletin = function () {

                                $scope.bulletinCheck.startTime = formatTime($scope.bulletinCheck.startTime);
                                $scope.bulletinCheck.endTime   = formatTime($scope.bulletinCheck.endTime);

                                if( testFormAllContent($scope.bulletinCheck) ){
                                    alert( testFormAllContent($scope.bulletinCheck) );
                                    return;
                                }

                                netManager.put(
                                    '/bulletins/' + $scope.bulletinCheck.id,
                                    { bulletinCheck: $scope.bulletinCheck }
                                ).then(function (result) {
                                    pageChanged();
                                    $scope.close();
                                });
                            }

                        }
                    });
                });
            }

            $scope.delete = function (id) {
                $uibModal.open({
                    templateUrl: "delete_modal",
                    animation  : true,
                    backdrop   : "static",
                    controller : function($scope,$uibModalInstance){
                        $scope.confirm = function () {
                            netManager.delete('/bulletins/' + id)
                                .then(function() {
                                    $uibModalInstance.close();
                                    $scope.pageChanged();
                                });
                        };
                        $scope.cancel = function(){
                            $uibModalInstance.close();
                        }
                    }
                });
            };

        }
    ]);

    app.controller('ProductController', [
        '$scope',
        '$uibModal',
        'netManager',
        function($scope, $uibModal, netManager) {

            $scope.products    = [];

            $scope.maxSize     = 5;
            $scope.totalItems  = 0;
            $scope.currentPage = 1;
            $scope.pageCount   = 5;

            $scope.pageChanged = function() {
                netManager.get('/products', { page: $scope.currentPage, page_count: $scope.pageCount })
                    .then(function(response) {
                        var results = response.data;

                        $scope.totalItems = results.count;
                        $scope.products   = results.data;
                    });
            };

            $scope.pageChanged();

            $scope.add = function () {
                $uibModal.open({
                    templateUrl: "add_modal",
                    backdrop   : "static",
                    animation  : true,
                    resolve    : {
                        pageChanged: function () {
                            return $scope.pageChanged
                        }
                    },
                    controller:function($scope, $uibModalInstance, pageChanged){

                        $scope.productAdd = {
                            name   : '',
                            desc   : '',
                            price  : 0,
                            tokens : 0,
                            upShelf: true
                        };

                        $scope.close=function(){
                            $uibModalInstance.close();
                        }

                        $scope.addProduct = function () {

                            $scope.testFormContentIsNull = function (obj) {
                                var nullVal = '';
                                var keyToChinese = [];
                                for(var key in obj){
                                    if(parseInt(obj[key]) == 0){
                                        continue;
                                    }
                                    console.log(obj[key]);

                                    if(obj[key] == '' || obj[key] == undefined){
                                        switch (key){
                                            case 'name':
                                                keyToChinese[key] = '**商品名称**';
                                                break;
                                            case 'desc':
                                                keyToChinese[key] = '**商品描述**';
                                                break;
                                            case 'price':
                                                keyToChinese[key] = '**商品价格**';
                                                break;
                                            default:
                                                keyToChinese[key] = '**代币数量**';
                                        }
                                        nullVal += keyToChinese[key] + ' 不能为空\n\n';
                                    }
                                }

                                if(nullVal != ''){
                                    return nullVal;
                                }

                                return;
                            }

                            if( $scope.testFormContentIsNull($scope.productAdd) ){
                                return $scope.testFormContentIsNull($scope.productAdd);
                            }

                            if($scope.productAdd.upShelf){
                                $scope.productAdd.upShelf = 1;
                            }else{
                                $scope.productAdd.upShelf = 0;
                            }

                            netManager.post(
                                '/products',
                                {
                                    productAdd: $scope.productAdd
                                }
                            ).then(function (result) {
                                pageChanged();
                                $scope.close();
                            });


                        }
                    }
                });
            }

            $scope.check = function (id) {
                netManager.get('/products/' + id
                ).then(function(response) {
                    $scope.currentProduct = response.data;
                }).then(function() {
                    $uibModal.open({
                        templateUrl: "check_modal",
                        backdrop   : "static",
                        animation  : true,
                        resolve    : {
                            currentProduct: function () {
                                return angular.copy($scope.currentProduct);
                            },
                            pageChanged   : function () {
                                return $scope.pageChanged;
                            }
                        },
                        controller: function ($scope, $uibModalInstance, currentProduct, pageChanged) {

                            $scope.productCheck = currentProduct;
                            $scope.close = function () {
                                $uibModalInstance.close();
                            }

                            $scope.alterProduct = function () {

                                netManager.put(
                                    '/products/' + $scope.productCheck.id,
                                    { productCheck: $scope.productCheck }
                                ).then(function (result) {
                                    pageChanged();
                                    $scope.close();
                                });
                            }

                        }
                    });
                });
            }

            $scope.delete = function (id) {
                $uibModal.open({
                    templateUrl : "delete_modal",
                    animation   : true,
                    backdrop    : "static",
                    controller  : function($scope,$uibModalInstance){
                        $scope.confirm = function () {
                            netManager.delete('/products/' + id
                            ).then(function() {
                                $scope.cancel();
                                $scope.pageChanged();
                            });
                        };

                        $scope.cancel = function(){
                            $uibModalInstance.close();
                        }
                    }
                });
            };

        }
    ]);

    app.controller('SystemController', [
        '$scope',
        function($scope) {
        }
    ]);

    app.controller('StatsController', [
        '$scope',
        function($scope) {
        }
    ]);
}());