

/*
 * Server Dependencies
 */
var debug = require('debug')('u-practice:controller:users');
var ServerError = require('../errors/server-error');
var GameDB = require('../../models/game');
var User = GameDB.models.user;
var Agent = GameDB.models.agent;


/*
 * UModules Dependencies
 */
var Game = require('../../game/');
var GE = Game.ERROR;

module.exports = {
    name: "agents",

    list: function(req, res, next) {
        var body        = {};
        var page        = parseInt(req.query.page) || 1;
        var pageCount   = parseInt(req.query.page_count) || 50;
        var isBind      = req.query.isBind;
        var userid      = req.query.userid;

        Agent.findAndCountAll({
            where: {
                system          : 0,
                agent           : 1,
                isBind          : isBind,
                parentID        : userid
            },
            offset: (page - 1) * pageCount,
            limit: pageCount
        }).then(function(results) {

            var records = results.rows;
            var count = results.count;

            body.count      = count;
            body.total      = Math.ceil(count/pageCount);
            body.page       = page;
            body.pageCount  = pageCount;
            body.data       = [];

            if(isBind == 0){

                records.forEach(function(record) {
                     var data = record.toJSON();

                     delete data.password;
                     delete data.player;

                     body.data.push(data);
                });

                delete body.useridData;

                res.success(body);
                return;
            }

            body.useridData = [];

            records.forEach(function(record) {
                body.useridData.push(record.toJSON().userid);
            });

            User.findAndCountAll({
                where: {
                    id: {
                        $in: body.useridData
                    },
                    accountStatus   : {
                        $or: [0, 1]
                    }
                }
            }).then(function (results) {
                var records = results.rows;

                records.forEach(function(record) {
                    var data = record.toJSON();

                    delete data.password;
                    delete data.player;

                    body.data.push(record.toJSON());
                });

                delete body.useridData;
                console.log(body);
                res.success(body);
            });
        }).catch(function(e) {
            next(e);
        });

        /*var count = results.count;
         var records = results.rows;

         body.count      = count;
         body.total      = Math.ceil(count/pageCount);
         body.page       = page;
         body.pageCount  = pageCount;
         body.data       = [];
         body.useridData = [];

         records.forEach(function(record) {
         var data = record.toJSON();

         delete data.password;
         delete data.player;

         body.data.push(data);
         });

         res.success(body);*/
    },

    get: function(req, res, next) {
        var id = req.params.id;

        User.findOne({
            where: { id: id }
        }).then(function(record) {
            if (record == null) {
                res.error(GE.NOT_EXISTS);
                return;
            }

            res.success(record.toJSON());
        }).catch(function(e) {
            next(e);
        });
    },

    query: function(req, res, next) {
        var id = req.params.id;
        var tableName = req.body.tableName;
        if(tableName == 'user'){
            tableName = User;
        }else{
            tableName = Agent;
        }

        tableName.findOne({
            where: { id: id }
        }).then(function(record) {
            if (record == null) {
                res.error(GE.NOT_EXISTS);
                return;
            }

            res.success(record.toJSON());
        }).catch(function(e) {
            next(e);
        });
    },

    create: function(req, res, next) {
        var agent = req.body.agent;

        Agent.findOne({
            where: { account: agent.account }
        }).then(function (record) {
            if (record != null) {
                throw new ServerError(GE.ALREADY_EXISTS);
            }

            return Agent.create({
                account : agent.account,
                password: agent.password,
                parentID: agent.parentID,
                agent   : 1,
                system  : 0
            });
        }).then(function(record) {
            res.success(record.toJSON());
        }).catch(function(e) {
            next(e);
        });
    },

    update: function(req, res, next) {
        var id = req.params.id;
        var tableName = req.body.tableName;
        if(tableName == 'user'){
            tableName = User;
        }else{
            tableName = Agent;
        }

        tableName.update({
            password: req.body.newPassword
        }, {
            where: { id: id }
        }).then(function(results) {
            res.success();
        }).catch(function(e) {
            next(e);
        });
    },

    updateAccountStatus: function(req, res, next) {
        var id              = req.params.id;
        var accountStatus   = req.body.accountStatus;

        if(accountStatus == 0){
            accountStatus = 1;
        }else if(accountStatus == 1){
            accountStatus = 0;
        }

        User.update({
            accountStatus: accountStatus
        }, {
            where: { id: id }
        }).then(function(results) {
            res.success();
        }).catch(function(e) {
            next(e);
        });
    },

    updateOrDelete: function(req, res, next) {
        var id = req.params.id;
        var tableName = req.body.tableName;

        if(tableName == 'user'){
            User.update({
                accountStatus: 2
            }, {
                where: { id: id }
            }).then(function(results) {
                res.success();
            }).catch(function(e) {
                next(e);
            });
            return;
        }

        Agent.destroy({
            where: { id: id }
        }).then(function(results) {
            res.success();
        }).catch(function(e) {
            next(e);
        });
    },

    delete: function(req, res, next) {
        var id = req.params.id;

        Agent.destroy({
            where: { id: id }
        }).then(function(results) {
            res.success();
        }).catch(function(e) {
            next(e);
        });
    },
};
